## :notebook:ft_printf

This project is pretty straight forward. You will recode printf. You will then be allowed to reuse the function in your future projects. You will mainly learn how to use variadic arguments.



#### key concepts

You should look precisely how real printf function works. ***hint : minus - space - zero - space - putnbr or putchar***



#### test programs

[42TESTERS-PRINTF by Mazoise](https://github.com/Mazoise/42TESTERS-PRINTF)

[printf_lover_v2 by charMstr](https://github.com/charMstr/printf_lover_v2)

[pft by gavinfielder](https://github.com/gavinfielder/pft)