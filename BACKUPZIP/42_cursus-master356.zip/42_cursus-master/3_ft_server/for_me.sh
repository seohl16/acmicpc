git clone https://github.com/alexandregv/42toolbox.git ~/42toolbox
cd ~/42toolbox
bash init_docker.sh
