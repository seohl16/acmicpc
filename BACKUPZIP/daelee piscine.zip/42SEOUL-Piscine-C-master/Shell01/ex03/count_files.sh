find . | wc -l | sed -e 's/^[ \t]*//'
