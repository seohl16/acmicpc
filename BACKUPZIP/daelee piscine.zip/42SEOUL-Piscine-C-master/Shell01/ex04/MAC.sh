ifconfig | grep '\tether' | cut -c 8- | tr -d " "
