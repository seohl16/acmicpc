#include "ft_putstr.c"

int main()
{
	char arr[ ] = "my name is daehyun lee. i wanna pass this La Piscine.";
	ft_putstr(arr);
}
