#include "ft_strlen.c"
#include <stdio.h>

int main()
{
	char arr[] = "hello world";
	int a = ft_strlen(arr);
	printf("%d\n", a);
	return 0;
}
