#include "ft_swap.c"

int main()
{
	int a = 1;
	int b = 42;

	ft_swap(&a, &b);

	return 0;
}
