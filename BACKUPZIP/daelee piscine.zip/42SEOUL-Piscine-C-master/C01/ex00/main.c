#include "ft_ft.c"

int	main()
{
	int num;

	num = 10;
	ft_ft(&num);
	return (0);
}
