#include "ft_div_mod.c"

int main()
{
	int i = 23;
	int j = 10;
	int c = 0;
	int d = 0;

	ft_div_mod(i, j, &c, &d); 
	
	return 0;
}
