#include "ft_print_memory.c"

int main()
{
	ft_print_memory();
}
