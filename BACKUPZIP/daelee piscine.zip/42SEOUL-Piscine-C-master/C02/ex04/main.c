#include "ft_str_is_lowercase.c"
#include <stdio.h>

int main()
{
	int test = 0;

	char arr[ ] = "sd";
	test = ft_str_is_lowercase(arr);
	printf("%d\n", test);
}
