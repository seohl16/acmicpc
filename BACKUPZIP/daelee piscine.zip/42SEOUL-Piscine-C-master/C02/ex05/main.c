#include "ft_str_is_uppercase.c"
#include <stdio.h>

int main()
{
	int test = 0;

	char arr[ ] = "SDD";
	test = ft_str_is_uppercase(arr);
	printf("%d\n", test);
}
