#include "ft_recursive_power.c"
#include <stdio.h>

int main()
{
	printf("%d\n", ft_recursive_power(2, 10));	
	return 0;
}
