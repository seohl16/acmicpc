#include <stdio.h>

#include "ft_iterative_factorial.c"

int main()
{
	printf("%d\n", ft_iterative_factorial(5));
	return 0;
}
