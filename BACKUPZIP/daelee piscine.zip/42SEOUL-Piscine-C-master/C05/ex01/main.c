#include <stdio.h>

#include "ft_recursive_factorial.c"

int main()
{
	printf("%d\n", ft_recursive_factorial(-12));
	printf("%d\n", ft_recursive_factorial(0));
	printf("%d\n", ft_recursive_factorial(1));
	return 0;
}
