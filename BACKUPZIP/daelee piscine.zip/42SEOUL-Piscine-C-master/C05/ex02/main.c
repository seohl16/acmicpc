#include "ft_iterative_power.c"
#include <stdio.h>

int main()
{
	printf("%d\n", ft_iterative_power(2, 10));
	return 0;
}
