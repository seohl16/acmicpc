#include "ft_putstr.c"

int		main()
{
	char arr[ ] = "hello, world!\n";
	ft_putstr(arr);
	return 0;
}
