#include "ft_putnbr.c"

int		main()
{
	ft_putnbr(5);		
	ft_putnbr(12345);		
	ft_putnbr(-12345);		
	ft_putnbr(-2147483648);		
	ft_putnbr(0);		
	return 0;
}
