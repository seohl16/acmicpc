#include "ft_print_alphabet.c"

int main()
{
	ft_print_alphabet();
	return 0;
}
