# 5부 콘텐츠 발행 및 배포

## [18장](./18_Web_Hosting.md) :octopus: 웹 호스팅
- __18.1__ 　  호스팅 서비스　 `daelee`
- __18.2__ 　  가상 호스팅　 `daelee`
- __18.3__ 　  안정적인 웹 사이트 만들기　 `secho`
- __18.4__ 　  웹 사이트 빠르게 만들기　 `secho`
<br>

## [20장](./20_Redirection_and_Load_Balancing.md) :octopus: 리다이렉션과 부하 균형
- __20.1__ 　  왜 리다이렉트인가?　 `jehong`
- __20.2__ 　  리다이렉트 할 곳　 `jehong`
- __20.3__ 　  리다이렉션 프로토콜의 개요　 `jehong`
- __20.4__ 　  일반적인 리다이렉션 방법
    - __20.4.1~2__　 `taelee`
    - __20.4.3~6__　 `yeosong`
<br>

## [21장](./21_Logging_and_Usage_Tracking.md) :octopus: 로깅과 사용추적
- __21.1__ 　  로그란 무엇인가?　 `hylee`
- __21.2__ 　  로그 포맷 (일반로그포맷 21.2.1만!)　 `hylee`
- __21.3__ 　  적중 계량하기　 `kukim`
- __21.4__ 　  개인 정보 보호에 대해 `kukim`
<br>
