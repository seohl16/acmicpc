/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iwoo <iwoo@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/08/17 17:50:47 by iwoo              #+#    #+#             */
/*   Updated: 2020/08/24 09:47:05 by iwoo             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ZombieHorde.hpp"

int main(void)
{
    ZombieHorde horde(10);
    std::cout<<"================="<<std::endl;
    std::cout<<"The sun is rising"<<std::endl;
    std::cout<<"================="<<std::endl;
    return (0);
}
