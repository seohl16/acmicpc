#include "container_test.hpp"

int main(int argc, const char *argv[])
{
    if (argc != 2)
    {
        std::cerr<<"Error invalid input"<<std::endl;
        return (1);
    }

    std::string container_type(argv[1]);
    if (container_type == "vector")
        vectorTest();
    else if (container_type == "list")
        listTest();
    else if (container_type == "stack")
        stackTest();
    else if (container_type == "queue")
        queueTest();
    else if (container_type == "map")
        mapTest();
    else
    {
        std::cerr<<"No match with container"<<std::endl;
    }
    
    return (0);
}