# Ft_Server

이 프로젝트는 42seoul 커리큘럼에 포함되어있습니다. 42seoul의 norm과 제약사항(ex for문 쓸 수 없음, 한 함수는 25줄을 넘을 수 없음, 허용되는 함수만 쓸 것 등등)에 따라 코딩되어 있습니다.
프로젝트의 내용은 [링크](https://github.com/moon9ua/42_seoul/wiki/2.-ft_server)에서 확인할 수 있습니다.

- 프로젝트 요구사항으로 docker-compose는 금지되어있습니다.
- docker hub에서 이미지를 가져와 쓸 수 없습니다. Nginx, WordPress, phpMyAdmin, SQL database 모두 debian buster 이미지에서 직접 build해야합니다.