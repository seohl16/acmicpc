#ifndef CUB3D_H
# define CUB3D_H

# include <mlx.h>
# include "game.h"
# include "type.h"
#include "hook.h"

#endif
