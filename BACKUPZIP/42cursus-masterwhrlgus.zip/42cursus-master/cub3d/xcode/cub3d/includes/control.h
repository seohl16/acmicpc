#ifndef control_h
# define control_h

#include "type.h"

void calc_movement(t_player *p, t_control* control);

#endif
