#ifndef texture_h
#define texture_h

#include <stdlib.h>
#include <mlx.h>
#include "type.h"

int load_texture(t_texture *texture, char *file_path);
#endif 
