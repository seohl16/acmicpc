#ifndef sprite_h
#define sprite_h

#include "type.h"
#include "utility.h"

int init_sprite(t_list **head, t_map *map);
#endif 
